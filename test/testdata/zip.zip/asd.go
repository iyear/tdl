package main

import (
	"time"

	"github.com/davecgh/go-spew/spew"
)

func main() {
	loc, _ := time.LoadLocation("Indian/Cocos")

	spew.Dump(time.Now().In(loc))
	spew.Dump(time.Now())

}
